package com.kodokdisko.individualproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class listMobil {

    //public String color;
    public String merk;
    public String tahun;


    public listMobil(String merk, String tahun) {
        //this.color = color;
        this.merk = merk;
        this.tahun = tahun;
    }

    /*public String getColor() {
        return color;
    }*/

    /*public void setColor(String color) {
        this.color = color;
    }*/

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public String getTahun() {
        return tahun;
    }

    public void setTahun(String tahun) {
        this.tahun = tahun;
    }
}