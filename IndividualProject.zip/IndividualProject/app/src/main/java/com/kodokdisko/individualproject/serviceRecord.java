package com.kodokdisko.individualproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class serviceRecord extends AppCompatActivity {

    List<listService> element;
    DBHelper DB;
    String merk, tahun, plat, jenis_service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_record);
        init();
    }
    public void init(){
        DB = new DBHelper(this);
        Cursor usersCursor = DB.getData();
        if (usersCursor.getCount() == 0) {
            Toast.makeText(serviceRecord.this, "DATA KOSONG", Toast.LENGTH_SHORT).show();
            return;
        }
        element = new ArrayList<>();

//        StringBuffer buffer = new StringBuffer();
        System.out.println(usersCursor);
        while (usersCursor.moveToNext()) {

            merk = usersCursor.getString(3);
            tahun = usersCursor.getString(4);
            plat = usersCursor.getString(6);
            jenis_service = usersCursor.getString(0);
            element.add(new listService(merk, tahun, plat, jenis_service));


        }
        recordAdapter listSiswa = new recordAdapter(element, this);
        RecyclerView recyclerView = findViewById(R.id.listRecyclerViewService);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listSiswa);
    }
}