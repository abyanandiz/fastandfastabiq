package com.kodokdisko.individualproject;

public class listService {
    public String merk;
    public String tahun;
    public String jenis_service;
    public String plat;

    public String getMerk(){return merk;}
    public String getTahun(){return tahun;}
    public String getJenis_service(){return jenis_service;}
    public String getPlat(){return plat;}

    public listService(String merk, String tahun, String jenis_service, String plat){
        this.merk = merk;
        this.tahun = tahun;
        this.jenis_service = jenis_service;
        this.plat = plat;
    }
}
