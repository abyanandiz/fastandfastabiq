package com.kodokdisko.individualproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Outlet extends AppCompatActivity {

    List<listOutlet> elements;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outlet);

        init();
    }
    public void init(){
        loading = ProgressDialog.show(Outlet.this, "loading data", "Please wait");
        elements = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://fastandfastabiq-default-rtdb.asia-southeast1.firebasedatabase.app/lokasi.json";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject alamatArray = jsonObject.getJSONObject("-NKTCJsR5UJAkOh4eI_B");
//                    ambil data
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        alamatArray.keys().forEachRemaining(key -> {
                            try {
                                Object value = alamatArray.get(key);
                                JSONObject jsonObject1 = (JSONObject) value;
                                //System.out.println(jsonObject1.get("nama_wilayah"));
                                String alamat = (String) jsonObject1.get("Alamat");
                                String area = (String) jsonObject1.get("Area beroperasi");
                                String nomor = (String) jsonObject1.get("Nomor telfon");
                                String provinsi = (String) jsonObject1.get("Provinsi");
                                elements.add(new listOutlet(alamat,area,nomor,provinsi));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        });
                    }

                    adapterOutlet listadapter = new adapterOutlet(elements, Outlet.this);
                    RecyclerView recyclerView = findViewById(R.id.outletRC);
                    recyclerView.setHasFixedSize(true);
                    recyclerView.setLayoutManager(new LinearLayoutManager(Outlet.this));
                    recyclerView.setAdapter(listadapter);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Outlet.this, "ERROR CONNECT TO API", Toast.LENGTH_LONG).show();
            }
        });
    }
}