package com.kodokdisko.individualproject;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.kodokdisko.individualproject.ui.gallery.GalleryFragment;

public class editProfile extends Fragment implements View.OnClickListener {
    View view;
    EditText name, hp;
    Button save, cancel;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_edit_profile, container,false);


        name = (EditText)view.findViewById(R.id.nameInput);
        hp = (EditText)view.findViewById(R.id.hpInput);

        save = (Button)view.findViewById(R.id.saveEdit);
        cancel = (Button)view.findViewById(R.id.cancelEdit);

        /*save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //FragmentManager fragmentManager = getSupportFragmentManager();
                //FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Bundle bundle = new Bundle();
                bundle.putString("name",name.getText().toString());
                getParentFragmentManager().setFragmentResult();
                GalleryFragment galleryFragment = new GalleryFragment();

                galleryFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.flFragment,galleryFragment).commit();
            }
        });*/

        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.saveEdit) {
            Bundle bundle = new Bundle();
            String hasilNama = name.getText().toString();
            bundle.putString("name",hasilNama);
            GalleryFragment galleryFragment = new GalleryFragment();

            galleryFragment.setArguments(bundle);

            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, galleryFragment).commit();
        }
    }
}