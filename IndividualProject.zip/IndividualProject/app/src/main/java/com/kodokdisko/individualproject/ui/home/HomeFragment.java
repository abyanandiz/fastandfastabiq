package com.kodokdisko.individualproject.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.kodokdisko.individualproject.BookService;
import com.kodokdisko.individualproject.Login;
import com.kodokdisko.individualproject.Outlet;
import com.kodokdisko.individualproject.R;
import com.kodokdisko.individualproject.Register;
import com.kodokdisko.individualproject.myCar;
import com.kodokdisko.individualproject.serviceRecord;


public class HomeFragment extends Fragment {
    View view;
    Button bookService,record, mycar, outlet;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.fragment_home, container, false);

        bookService = (Button)view.findViewById(R.id.bookService);
        bookService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(getActivity(), BookService.class);
                startActivity(pindah);
            }
        });

        record = (Button) view.findViewById(R.id.recordBtn);
        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah2 = new Intent(getActivity(), serviceRecord.class);
                startActivity(pindah2);
            }
        });

        mycar = (Button)view.findViewById(R.id.mycarBtn);
        mycar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah4 = new Intent(getActivity(), myCar.class);
                startActivity(pindah4);
            }
        });

        outlet=(Button)view.findViewById(R.id.outletBtn);
        outlet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah5 = new Intent(getActivity(), Outlet.class);
                startActivity(pindah5);
            }
        });
        return view;

        //final TextView textView = binding.textHome;
        //homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        //return root;


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //binding = null;
    }
}