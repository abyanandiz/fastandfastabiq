package com.kodokdisko.individualproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class adapterOutlet extends RecyclerView.Adapter<adapterOutlet.ViewHolder>{
    private List<listOutlet> mData2;
    private LayoutInflater mInflater2;
    private Context context2;

    public adapterOutlet(List<listOutlet> itemList, Context context) {
        this.mInflater2 = LayoutInflater.from(context);
        this.context2 = context;
        this.mData2 = itemList;
    }

    @NonNull
    @Override
    public adapterOutlet.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater2.inflate(R.layout.activity_list_outlet, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull adapterOutlet.ViewHolder holder, int position) {
        holder.bindData(mData2.get(position));
    }

    @Override
    public int getItemCount() {
        return mData2.size();
    }

    public void setItems(List<listOutlet> items) {
        mData2 = items;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView alamat,area,nomor,provinsi;

        public ViewHolder(View itemview) {
            super(itemview);
            alamat = itemview.findViewById(R.id.tvAlamat);
            area = itemview.findViewById(R.id.tvArea);
            nomor = itemview.findViewById(R.id.tvNomor);
            provinsi = itemview.findViewById(R.id.tvProv);
        }

        public void bindData(listOutlet listOutlet) {
            alamat.setText(listOutlet.getAlamat());
            area.setText(listOutlet.getArea());
            nomor.setText(listOutlet.getNomor());
            provinsi.setText(listOutlet.getProvinsi());
        }
    }
}
