package com.kodokdisko.individualproject;

public class listOutlet {

    public String alamat;
    private String area;
    private String nomor;
    private String provinsi;


    public listOutlet(String alamat, String area, String nomor, String provinsi) {
        this.alamat = alamat;
        this.area = area;
        this.nomor = nomor;
        this.provinsi = provinsi;
    }



    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String city) {
        this.alamat = alamat;
    }


    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getNomor() {
        return nomor;
    }

    public void setNomor(String nomor) {
        this.nomor = nomor;
    }

    public String getProvinsi() {
        return provinsi;
    }

    public void setProvinsi(String provinsi) {
        this.provinsi = provinsi;
    }
}

