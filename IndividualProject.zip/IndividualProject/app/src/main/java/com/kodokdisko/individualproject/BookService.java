package com.kodokdisko.individualproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class BookService extends AppCompatActivity {

    Button saveBook, backHome;
    EditText tanggal_book, merk_kendaraan, tahun_kendaraan, odometer, plat, notes;
    Spinner jenisService, outlet;
    DBHelper DB;

    String JenisService, Outlet, Tanggal, Merk, Tahun, Odo, Plat, Notes;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_service);

        DB = new DBHelper(this);

        saveBook = (Button) findViewById(R.id.saveBook);
        backHome = (Button) findViewById(R.id.backHome);

        tanggal_book = (EditText) findViewById(R.id.tanggal_book_et);
        merk_kendaraan = (EditText) findViewById(R.id.merk_kendaraan_et);
        tahun_kendaraan = (EditText) findViewById(R.id.tahun_kendaraan_et);
        odometer = (EditText) findViewById(R.id.odometer_et);
        plat = (EditText) findViewById(R.id.plat_et);
        notes = (EditText) findViewById(R.id.notes_et);

        jenisService = (Spinner) findViewById(R.id.jenis_service_spinner);
        outlet = (Spinner) findViewById(R.id.outlet_spinner);

/*        Intent getIntent = getIntent();
        hasilPlat = getIntent.getStringExtra("plat");

        if (hasilPlat != null) {
            tampil();
        }*/

        backHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getBaseContext(), "back to Home", Toast.LENGTH_LONG).show();
                Intent pindah = new Intent(BookService.this, MainActivity.class);
                startActivity(pindah);
                finish();
            }
        });
        saveBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JenisService = jenisService.getSelectedItem().toString();
                Outlet = outlet.getSelectedItem().toString();
                Tanggal = tanggal_book.getText().toString();
                Merk = merk_kendaraan.getText().toString();
                Tahun = tahun_kendaraan.getText().toString();
                Odo = odometer.getText().toString();
                Plat = plat.getText().toString();
                Notes = notes.getText().toString();

                Boolean checkinsertdata = DB.insertuserdata(JenisService, Outlet, Tanggal, Merk, Tahun, Odo, Plat, Notes);
                if (checkinsertdata == true) {
                    Toast.makeText(BookService.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(BookService.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

/*                String textButton = (String) saveBook.getText();

                if (tanggal_book.getText().toString().equals("")) {// jika edit text kosong
//                    tampilkan peringatan berupa toast/ set Error/ alert
                    tanggal_book.setError("Tolong isi tanggal book");
                } else if (merk_kendaraan.getText().toString().equals("")) {
                    merk_kendaraan.setError("Tolong isi merk kendaraan anda");
                } else if (tahun_kendaraan.getText().toString().equals("")) {
                    tahun_kendaraan.setError("Tolong isi tahun kendaraan anda");
                } else if (odometer.getText().toString().equals("")) {
                    odometer.setError("Tolong isi odometer anda");
                } else if (plat.getText().toString().equals("")) {
                    plat.setError("Tolong isi nomor plat kendaraan anda");
                } else if (jenisService.getSelectedItemPosition() == 0) {
                    Toast.makeText(getBaseContext(), "Pilih jenis service yang anda inginkan", Toast.LENGTH_LONG).show();
                } else if (outlet.getSelectedItemPosition() == 0) {
                    Toast.makeText(getBaseContext(), "Pilih outlet service terdekat anda", Toast.LENGTH_LONG).show();
                } else {
                    if (textButton.equals("Update")) {
                        boolean updateSuccess = DB.updateUserData(
                                tanggal_book.getText().toString(),
                                merk_kendaraan.getText().toString(),
                                tahun_kendaraan.getText().toString(),
                                odometer.getText().toString(),
                                plat.getText().toString(),
                                jenisService.getSelectedItem().toString(),
                                outlet.getSelectedItem().toString(),
                                notes.getText().toString());
                        if (updateSuccess) {
                            Toast.makeText(BookService.this, "UPDATE SUKSES", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(BookService.this, serviceRecord.class));
                            finish();
                        } else {
                            Toast.makeText(BookService.this, "UPDATE GAGAL", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        //                    Toast.makeText(PendaftaranBaru.this, name.getText().toString(), Toast.LENGTH_LONG).show();
//                    System.out.println(username.getText().toString() + " " + name.getText().toString());
                        boolean insertSuccess = DB.insertUserData(
                                tanggal_book.getText().toString(),
                                merk_kendaraan.getText().toString(),
                                tahun_kendaraan.getText().toString(),
                                odometer.getText().toString(),
                                plat.getText().toString(),
                                jenisService.getSelectedItem().toString(),
                                outlet.getSelectedItem().toString(),
                                notes.getText().toString());
                        System.out.println(insertSuccess);
                        if (insertSuccess) {
                            Toast.makeText(BookService.this, "INSERT DATA SUKSES", Toast.LENGTH_LONG).show();
                            Intent hasilform = new Intent(BookService.this, MainActivity.class);
                            startActivity(hasilform);
                            finish();
                        } else {
                            Toast.makeText(BookService.this, "INSERT GAGAL", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        }
    }
    public void tampil() {
//        DB = new DBHelper3(this);
        saveBook.setText("Update");
        plat.setVisibility(View.INVISIBLE);
//        System.out.println(btn.getId());
        Cursor usersCursor = DB.getPlat();

        while (usersCursor.moveToNext()) {
            plat = usersCursor.getString(0);
            nama = usersCursor.getString(1);
            phone = usersCursor.getString(2);
            alamatSiswa = usersCursor.getString(3);
            Kelas = usersCursor.getString(4);
            bimbingan = usersCursor.getString(6);
            asal = usersCursor.getString(5);
            hari = usersCursor.getString(7);
            if (user.equals(hasilUser)) {
                name.setText(nama);
                username.setText(user);
                no_hp.setText(phone);
                alamat.setText(alamatSiswa);
                kelas.setText(Kelas);
                namaBimbingan.setSelection(((ArrayAdapter<String>) namaBimbingan.getAdapter()).getPosition(bimbingan));
                asalSekolah.setText(asal);
                hariBimbingan.setText(hari);


            }
    }
}
*/