package com.kodokdisko.individualproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class myCar extends AppCompatActivity {
    List<listMobil> elements;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_car);
        elements = new ArrayList<>();
        elements.add(new listMobil("Toyota Camry", "2020"));
        elements.add(new listMobil("Honda CRX","1989"));

        carAdapter listAdapter = new carAdapter(elements, this);
        RecyclerView recyclerView = findViewById(R.id.myCarRC);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
    }
}