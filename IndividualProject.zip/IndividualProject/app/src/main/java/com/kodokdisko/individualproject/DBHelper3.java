package com.kodokdisko.individualproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper3 extends SQLiteOpenHelper {
    public DBHelper3(@Nullable Context context) {
        super(context, "service.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("CREATE TABLE book_service (jenis_service TEXT, outlet TEXT, tanggal_book TEXT, merk_kendaraan TEXT NOT NULL, tahun_kendaraan NUMERIC NOT NULL, odometer NUMERIC NOT NULL, plat TEXT PRIMARY KEY, notes TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int j) {
        DB.execSQL("DROP TABLE IF EXISTS book_service");
    }

    public boolean insertUserData(String jenisService, String outlet, String tanggal_book, String merk, String tahun_kendaraan, String odometer, String plat, String notes) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("jenis_service", jenisService);
        contentValues.put("outlet", outlet);
        contentValues.put("tanggal_book", tanggal_book);
        contentValues.put("merk_kendaraan", merk);
        contentValues.put("tahun_kendaraan", tahun_kendaraan);
        contentValues.put("odometer", odometer);
        contentValues.put("plat", plat);
        contentValues.put("notes", notes);

        long res = DB.insert("siswa", null, contentValues);
        return res != -1;
    }
    public boolean deleteUser(String plat) {
        SQLiteDatabase DB = this.getWritableDatabase();

        Cursor cursor = DB.rawQuery("SELECT * FROM book_service WHERE plat=?", new String[]{plat});
        if (cursor.getCount() > 0) {
            long res = DB.delete("book_service", "plat=?", new String[]{plat});
            return res != -1;
        } else {
            return false;
        }
    }
    public boolean updateUserData(String jenisService, String outlet, String tanggal_book, String merk, String tahun_kendaraan, String odometer, String plat, String notes) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("jenis_service", jenisService);
        contentValues.put("outlet", outlet);
        contentValues.put("tanggal_book", tanggal_book);
        contentValues.put("merk_kendaraan", merk);
        contentValues.put("tahun_kendaraan", tahun_kendaraan);
        contentValues.put("odometer", odometer);
        contentValues.put("plat", plat);
        contentValues.put("notes", notes);

        Cursor cursor = DB.rawQuery("SELECT * FROM book_service WHERE plat=?", new String[]{plat});
        if (cursor.getCount() > 0) {
            long res = DB.update("book_service", contentValues, "plat=?", new String[]{plat});
            return res != -1;
        } else {
            return false;
        }
    }
    public Cursor getPlat() {
        SQLiteDatabase DB = this.getWritableDatabase();

        Cursor cursor = DB.rawQuery("SELECT * FROM book_service", null);

        return cursor;
    }
}
