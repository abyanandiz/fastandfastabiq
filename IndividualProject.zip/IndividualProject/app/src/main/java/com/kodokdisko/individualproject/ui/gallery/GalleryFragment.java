package com.kodokdisko.individualproject.ui.gallery;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;

import com.kodokdisko.individualproject.R;
import com.kodokdisko.individualproject.databinding.FragmentGalleryBinding;
import com.kodokdisko.individualproject.editProfile;
import com.kodokdisko.individualproject.serviceRecord;

import org.w3c.dom.Text;

public class GalleryFragment extends Fragment {
    View view;
    private Button edit;
    String myStr;
    TextView textViewNama;

    private FragmentGalleryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_gallery, container,false);

        edit = view.findViewById(R.id.editProfileBtn);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah3 = new Intent(getActivity(), editProfile.class);
                startActivity(pindah3);

            }
        });
        Bundle bundle = this.getArguments();
        textViewNama= view.findViewById(R.id.nameTV);

        myStr = bundle.getString("name");

        textViewNama.setText(myStr);
        //textViewName.setText(this.getArguments().getString("name"));

        /*if (data != null) {
            myStr = data.getString("name");

        }
        textViewName.setText(myStr);*/
        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //binding = null;
    }
}