package com.kodokdisko.individualproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "service_record.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("CREATE TABLE book_service (jenis_service TEXT, outlet TEXT, tanggalBook TEXT, merkKendaraan TEXT NOT NULL, tahunKendaraan NUMERIC NOT NULL, odometer NUMERIC NOT NULL, plat TEXT PRIMARY KEY, notes TEXT NOT NULL)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("DROP TABLE IF EXISTS book_service");
    }

    public Boolean insertuserdata(
            String jenis,
            String outlet,
            String tanggal,
            String merk,
            String tahun,
            String odometer,
            String plat,
            String notes){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("jenis_service", jenis);
        contentValues.put("outlet", outlet);
        contentValues.put("tanggalBook", tanggal);
        contentValues.put("merkKendaraan", merk);
        contentValues.put("tahunKendaraan", tahun);
        contentValues.put("odometer", odometer);
        contentValues.put("plat", plat);
        contentValues.put("notes", notes);

        long result = DB.insert("book_service", null, contentValues);

        if(result==-1){
            return false;
        }
        else{
            return true;
        }
    }
    public Cursor getData(){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("SELECT * FROM book_service", null);
        return cursor;
    }
}
