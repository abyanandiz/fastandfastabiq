package com.kodokdisko.individualproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class recordAdapter extends RecyclerView.Adapter<recordAdapter.ViewHolder> {
    private Context context;
    private List<listService> mData;
    private LayoutInflater mInflater;


    public recordAdapter(List<listService> itemList, Context context) {
        this.mData = itemList;
        this.mInflater = LayoutInflater.from(context);;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.activity_recycler_view_card, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bindData(mData.get(position));

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
    public void setItems(List<listService> items) {
        mData = items;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageButton deleteBtn;
        ImageView editBtn;
        TextView merk, tahun, plat, jenis_service;

        public  ViewHolder(@NonNull View itemView){
            super(itemView);
            merk = (TextView) itemView.findViewById(R.id.etMerk);
            tahun = (TextView) itemView.findViewById(R.id.etTahun);
            plat = (TextView) itemView.findViewById(R.id.etPlat);
            jenis_service = (TextView) itemView.findViewById(R.id.etJenis);
            deleteBtn = itemView.findViewById(R.id.btnDelete);
            editBtn = itemView.findViewById(R.id.buttonEdit);
        }

        public void bindData(listService listService) {
            merk.setText(listService.getMerk());
            tahun.setText(listService.getTahun());
            plat.setText(listService.getPlat());
            jenis_service.setText(listService.getJenis_service());
        }
    }
}
