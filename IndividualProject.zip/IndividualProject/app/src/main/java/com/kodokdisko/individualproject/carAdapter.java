package com.kodokdisko.individualproject;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class carAdapter extends RecyclerView.Adapter<carAdapter.ViewHolder> {

    private List<listMobil> mData;
    private LayoutInflater mInflater;
    private Context context;

    public carAdapter(List<listMobil> itemList, Context context) {
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.mData = itemList;
    }

    @NonNull
    @Override
    public carAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.activity_list_mobil, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull carAdapter.ViewHolder holder, int position) {
        holder.bindData(mData.get(position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void setItems(List<listMobil> items) {
        mData = items;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView iconImage;
        TextView merk, tahun;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iconImage = itemView.findViewById(R.id.iconImageView);
            merk = itemView.findViewById(R.id.merkTextView);
            tahun = itemView.findViewById(R.id.tahunTextView);

        }

        public void bindData(final listMobil item) {
            merk.setText(item.getMerk());
            tahun.setText(item.getTahun());
        }
    }
}
