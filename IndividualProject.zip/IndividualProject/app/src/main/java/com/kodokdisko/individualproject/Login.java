package com.kodokdisko.individualproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {
    Button btn;
    Button btn2;
    EditText etUsername;
    EditText etPassword;
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn = (Button) findViewById(R.id.loginBtn);
        btn2 = (Button) findViewById(R.id.register_btn_login);
        etUsername = (EditText) findViewById(R.id.reg_username);
        etPassword = (EditText) findViewById(R.id.reg_pass);

        mAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(Login.this);
        progressDialog.setTitle("loading");
        progressDialog.setMessage("please wait");
        progressDialog.setCancelable(false);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etUsername.getText().toString().equals("")) {// jika edit text kosong
//                    tampilkan peringatan berupa toast set Error/ alert
                    etUsername.setError("Please Fill your username");
                } else if (etPassword.getText().toString().equals("")) {
                    etPassword.setError("Please Fill your password");
                } else {
                    login(etUsername.getText().toString(), etPassword.getText().toString());
                    Toast.makeText(getBaseContext(), "Log in success", Toast.LENGTH_LONG).show();
                    Intent pindah = new Intent(Login.this, MainActivity.class);
                    startActivity(pindah);
                    finish();
                }
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah2 = new Intent(Login.this, Register.class);
                startActivity(pindah2);
                finish();
            }
        });
    }
    private void reload(){
        startActivity(new Intent(getApplicationContext(), Login.class));
    }

    private void login(String email, String password){
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful() && task.getResult()!=null){
                    if (task.getResult().getUser()!=null){
                        reload();
                    }
                } else{
                    Toast.makeText(getApplicationContext(),"Login failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            reload();
        }
    }
}